$(document).ready(function(){

  $("a[href^='#']").click(function () {
	 elementClick = $(this).attr("href");
	 destination = $(elementClick).offset().top;
	 $("body,html").animate({scrollTop: destination }, 800);
  });

  $('.slider').slick({
	 arrows: false,
	 infinite:true,
	 autoplay: true,
	 autoplaySpeed: 2000,
	 slidesToShow:1,
	 slidesToScroll:1,
	 verticalSwiping: true,
	 vertical: true,
	 dots: true
  });

});